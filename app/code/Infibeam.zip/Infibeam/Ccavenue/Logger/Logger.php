<?php
namespace Infibeam\Ccavenue\Logger;

class Logger extends \Monolog\Logger
{
}