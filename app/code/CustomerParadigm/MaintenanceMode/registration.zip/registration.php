<?php

\Magento\Framework\Component\ComponentRegistrar::register(
   \Magento\Framework\Component\ComponentRegistrar::MODULE,
   'CustomerParadigm_MaintenanceMode',
   __DIR__
);

 
