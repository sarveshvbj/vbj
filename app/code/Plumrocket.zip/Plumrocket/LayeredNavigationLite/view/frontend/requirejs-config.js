var config = {
    map: {
        '*': {
            'prProductFilter': 'Plumrocket_LayeredNavigationLite/js/init',
            'prProductFilterSlider': 'Plumrocket_LayeredNavigationLite/js/view/price/slider',
            'jquery/ui-touch-punch': 'Plumrocket_LayeredNavigationLite/js/jquery/jquery.ui.touch-punch.min',
            'plumrocket/product-filter/action': 'Plumrocket_LayeredNavigationLite/js/model/filter-action',
            'plumrocket/noUiSlider': 'Plumrocket_LayeredNavigationLite/js/lib/nouislider.min',
        }
    }
};