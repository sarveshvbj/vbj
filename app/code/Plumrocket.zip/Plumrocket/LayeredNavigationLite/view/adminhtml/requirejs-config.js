var config = {
    map: {
        '*': {
            prProductFilterAdmin_attributes: 'Plumrocket_LayeredNavigationLite/js/filter'
        }
    }
};