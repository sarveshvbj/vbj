var config = {
    map: {
        '*': {
            'plumrocket/utils': 'Plumrocket_Base/js/utils'
        }
    }
};
