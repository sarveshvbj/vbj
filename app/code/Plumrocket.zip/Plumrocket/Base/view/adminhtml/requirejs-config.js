var config = {
    map: {
        '*': {
            jscolor: 'Plumrocket_Base/js/jscolor',
            pickr: 'Plumrocket_Base/js/lib/pickr.es5.min',
            prInfoPanel: 'Plumrocket_Base/js/info-panel',
        }
    }
};
