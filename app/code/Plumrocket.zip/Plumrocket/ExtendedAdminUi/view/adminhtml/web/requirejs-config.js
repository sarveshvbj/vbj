var config = {
    map: {
        '*': {
            pickr: 'Plumrocket_ExtendedAdminUi/js/lib/pickr.es5.min',
        }
    }
};
