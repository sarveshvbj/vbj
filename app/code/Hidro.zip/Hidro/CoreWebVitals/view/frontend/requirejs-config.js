var config = {
    map: {
        '*': {
            cwvLazyProductItem: 'Hidro_CoreWebVitals/js/lazy-load-product-item'
        }
    },
    config: {
        mixins: {
            'MSP_ReCaptcha/js/reCaptcha': {
                'Hidro_CoreWebVitals/js/reCaptcha-mixin': true
            }
        }
    }
};
