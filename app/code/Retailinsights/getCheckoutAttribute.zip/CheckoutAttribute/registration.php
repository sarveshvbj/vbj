<?php
use \Magento\Framework\Component\ComponentRegistrar;
ComponentRegistrar::register(
    ComponentRegistrar::MODULE,
    'Retailinsights_CheckoutAttribute',
    __DIR__
);
require_once(BP.'/lib/internal/Zoho/autoload.php');