<?php
namespace Retailinsights\ProductGamooga\Block;
 
class ProductGamooga extends \Magento\Framework\View\Element\Template
{
    public function getHelloWorldTxt()
    {
        return 'Hello world!';
    }
}