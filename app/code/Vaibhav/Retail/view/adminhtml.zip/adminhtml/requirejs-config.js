var config = {
    "map": {
        "*": {
            "Magento_Email/js/variables": "Vaibhav_Retail/js/variables_custom",
        }
    }
}