<?php
namespace Vaibhav\Retail\Plugin\Magento\Directory\Controller\Currency;

use Magento\Catalog\Model\ProductFactory;
use Magento\Checkout\Model\Cart;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Customer\Model\Session;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Quote\Model\Quote\Item;
use Magento\Framework\Data\Form\FormKey;
use Magento\Framework\View\Result\PageFactory;

class SwitchAction
{
    /**
     * @var StoreManager
     */
    protected $storeManager;

    /**
     * @var Session
     */
    protected $customerSession;

    /**
     * @var Cart
     */
    protected $cart;

    /**
     * @var CheckoutSession
     */
    protected $checkoutSession;

    /**
     * @var Product
     */
    protected $_product;

    /**
     * @var Item
     */
    protected $quoteFactory;

    /**
     * @var CartRepositoryInterface
     */
    protected $quoteRepository;

    /**
     * @var Formkey
     */
    protected $formKey;

    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    public function __construct(\Magento\Store\Model\StoreManagerInterface $storeManager, Session $customerSession, Cart $cart, CheckoutSession $checkoutSession, ProductFactory $_product, Item $quoteFactory, FormKey $formKey, CartRepositoryInterface $quoteRepository, PageFactory $resultPageFactory)
    {
        $this->storeManager = $storeManager;
        $this->customerSession = $customerSession;
        $this->cart = $cart;
        $this->checkoutSession = $checkoutSession;
        $this->_product = $_product;
        $this->formKey = $formKey;
        $this->quoteFactory = $quoteFactory;
        $this->quoteRepository = $quoteRepository;
        $this->resultPageFactory = $resultPageFactory;
    }

    public function afterExecute(\Magento\Directory\Controller\Currency\SwitchAction $subject)
    {
        $currentCurrency = $this->storeManager->getStore()->getCurrentCurrencyCode();
        //$newCurrency = $subject->getRequest()->getParam('currency');
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/beforeswitchlog.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info('current ' . $currentCurrency);
        //  $logger->info('newcurrency '.$newCurrency);
        // your code here
        $itemId = 0;
        $qty = 0;
        $quoteId = 0;
        $product_detail = array();
        $sessionItems = $this->checkoutSession->getQuote()->getAllItems();
        $quote = $this->checkoutSession->getQuote();
        $quoteId = $quote->getId();

        if ($sessionItems)
        {

            //             $itemsCollection = $this->cart->getQuote()->getItemsCollection();
            // // get array of all items what can be display directly
            // $itemsVisible = $this->cart->getQuote()->getAllVisibleItems();
            // // retrieve quote items array
            //  $items = $this->cart->getQuote()->getAllItems();
            // foreach($itemsCollection as $item) {
            //      $logger->info('_Name'.$item->getName().'_Qty'.$item->getQty().'_Price'.$item->getPrice());
            //   }
            foreach ($sessionItems as $session_item)
            {
                $qty = (int)$session_item['qty'];
                $productId = $session_item['product_id'];
                $product_detail[$productId] = $qty;
                //$product = $this->_product->load($productId);
                $setcustomprice = $this->checkoutSession->getQuote()->getItemById($session_item['item_id']);

                $logger->info('Quote Id ' . $quoteId);
                $logger->info('Quote Id ' . $session_item->getId());
                $this->cart->removeItem($session_item->getId());
                $this->cart->save();

                //3rd way
                // $cartItemId = $session_item->getItemId();
                //     $itemObj=$this->quoteFactory->load($cartItemId);
                //   $itemObj->delete();

                //2nd way
                // $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                // $cartObject = $objectManager->create('Magento\Checkout\Model\Cart')->truncate();
                // $cartObject->saveQuote();
                
            }

            $quote = $this->checkoutSession->getQuote();

            foreach ($product_detail as $product_id => $qty)
            {
                if ($product_id)
                {
                    $prod_id = 1329;
                    $logger->info('Aftersaved ID ' . $product_id . ' After Qty' . $qty);

                    $product = $this->_product->create()->load($prod_id);
                    $params = ['form_key' => $this->formKey->getFormKey() , 'product' => $product_id, 'qty' => $qty, ];

                    //Save Product
                    $product->save();

                    $this->cart->addProduct($product, $params);
                    $this->cart->save();

                    //product object method
                    // if ($product->getId()) {
                    //        $quote->addProduct(
                    //            $product,
                    //            intval($qty)
                    //        );
                    //    }
                    

                    
                }

            }
            //product object method save code
            // $this->quoteRepository->save($quote);
            // $this->checkoutSession->replaceQuote($quote)->unsLastRealOrderId();
            
        }

        // if ($quoteId) {
        //     $quote = $this->quoteRepository->get($quoteId);
        //     $this->quoteRepository->save($quote->collectTotals());
        // }
        
    }

}

